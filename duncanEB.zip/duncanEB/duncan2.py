# -*- coding: mbcs -*-
#
# Abaqus/CAE Release 6.14-5 replay file
# Internal Version: 2015_08_18-22.37.49 135153
# Run by Baron on Mon Dec 09 02:07:20 2019
#

# from driverUtils import executeOnCaeGraphicsStartup
# executeOnCaeGraphicsStartup()
#: Executing "onCaeGraphicsStartup()" in the site directory ...
from abaqus import *
from abaqusConstants import *
session.Viewport(name='Viewport: 1', origin=(0.0, 0.0), width=150, 
    height=200)
session.viewports['Viewport: 1'].makeCurrent()
session.viewports['Viewport: 1'].maximize()
from caeModules import *
from driverUtils import executeOnCaeStartup
executeOnCaeStartup()
session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
    referenceRepresentation=ON)
import os



os.chdir(r"D:\duncanEB")#�ǵ��޸�·��



#mdb.saveAs(pathName='E:/abaqus/UMAT/autoVertifyConstiviveModelUmat/CSUH/CSUH2')
#: ģ�����ݿ��ѱ��浽 "E:\abaqus\UMAT\autoVertifyConstiviveModelUmat\CSUH\CSUH2.cae".
a = mdb.models['Model-1'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
mdb.ModelFromInputFile(name='duncan', 
    inputFileName='duncan.inp')
#mdb.ModelFromInputFile(name='csuh', 
#    inputFileName='E:/abaqus/UMAT/autoVertifyConstiviveModelUmat/CSUH/csuh.inp')
#: ģ�� "csuh" �Ѵ���.
#: ���� "PART-1" �Ѵ������ļ��е���.
#: 
#: WARNING: The following keywords/parameters are not yet supported by the input file reader:
#: ---------------------------------------------------------------------------------
#: *PREPRINT
#: ģ�� "csuh" �Ѵ������ļ�����. 
#: �������϶��������Բ鿴����򾯸���Ϣ.
session.viewports['Viewport: 1'].assemblyDisplay.setValues(
    optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
a = mdb.models['duncan'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
mdb.Job(name='duncan2', model='duncan', description='', type=ANALYSIS, atTime=None, 
    waitMinutes=0, waitHours=0, queue=None, memory=90, memoryUnits=PERCENTAGE, 
    getMemoryFromAnalysis=True, explicitPrecision=SINGLE, 
    nodalOutputPrecision=SINGLE, echoPrint=OFF, modelPrint=OFF, 
    contactPrint=OFF, historyPrint=OFF, 
    userSubroutine='duncanEB_20200304C5kPa.for', 
    scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, 
    numDomains=1, numGPUs=0)
	
mdb.jobs['duncan2'].submit(consistencyChecking=OFF)
mdb.jobs['duncan2'].waitForCompletion()

#: ��ҵ�����ļ� "CSUH2.inp" ���ύ����.
#: Job CSUH2: Analysis Input File Processor completed successfully.
#: Job CSUH2: Abaqus/Standard completed successfully.
#: Job CSUH2 completed successfully. 
o3 = session.openOdb(
    name='duncan2.odb')
#: ģ��: E:/abaqus/UMAT/autoVertifyConstiviveModelUmat/CSUH/CSUH2.odb
#: װ�������:         1
#: װ���ʵ������: 0
#: ����ʵ���ĸ���:     1
#: ������:             1
#: ��Ԫ������:       4
#: ��㼯����:          4
#: �������ĸ���:              2
session.viewports['Viewport: 1'].setValues(displayedObject=o3)
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
    CONTOURS_ON_UNDEF, ))
odbName=session.viewports[session.currentViewportName].odbDisplay.name
session.odbData[odbName].setValues(activeFrames=(('Step-2', ('0:-1', )), ))
odb = session.odbs['duncan2.odb']
session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('E', 
    INTEGRATION_POINT, ((COMPONENT, 'E11'), (COMPONENT, 'E22'), (COMPONENT, 
    'E33'), )), ('S', INTEGRATION_POINT, ((COMPONENT, 'S11'), (COMPONENT, 
    'S22'), (COMPONENT, 'S33'), )), ), nodeLabels=(('PART-1-1', ('6', )), ))
xy1 = session.xyDataObjects['E:E33 (ƽ��: 75%) PI: PART-1-1 N: 6']
xy2 = -xy1
xy2.setValues(sourceDescription='-"E:E33 (ƽ��: 75%) PI: PART-1-1 N: 6"')
tmpName = xy2.name
session.xyDataObjects.changeKey(tmpName, 'XYData-1-e1')
xy1 = session.xyDataObjects['E:E11 (ƽ��: 75%) PI: PART-1-1 N: 6']
xy2 = session.xyDataObjects['E:E22 (ƽ��: 75%) PI: PART-1-1 N: 6']
xy3 = session.xyDataObjects['E:E33 (ƽ��: 75%) PI: PART-1-1 N: 6']
xy4 = -(xy1+xy2+xy3)
xy4.setValues(
    sourceDescription='-("E:E11 (ƽ��: 75%) PI: PART-1-1 N: 6"+"E:E22 (ƽ��: 75%) PI: PART-1-1 N: 6"+"E:E33 (ƽ��: 75%) PI: PART-1-1 N: 6")')
tmpName = xy4.name
session.xyDataObjects.changeKey(tmpName, 'XYData-1-ev')
xy1 = session.xyDataObjects['S:S33 (ƽ��: 75%) PI: PART-1-1 N: 6']
xy2 = session.xyDataObjects['S:S11 (ƽ��: 75%) PI: PART-1-1 N: 6']
xy3 = -(xy1-xy2)
xy3.setValues(
    sourceDescription='-("S:S33 (ƽ��: 75%) PI: PART-1-1 N: 6"-"S:S11 (ƽ��: 75%) PI: PART-1-1 N: 6")')
tmpName = xy3.name
session.xyDataObjects.changeKey(tmpName, 'XYData-1-q')
xy1 = session.xyDataObjects['XYData-1-e1']
xy2 = session.xyDataObjects['XYData-1-q']
xy3 = combine(xy1, xy2)

#----------------------------------------------------------------------------
# �����
xy_result1 = session.XYData(name='XYData-1e1q', objectToCopy=xy3, 
    sourceDescription='combine("XYData-1-e1", "XYData-1-q" )')
######################################################################
temp=open('duncanAbaquse1q.dat', 'w')
for  Data in xy_result1:
      print  Data
      temp.write('%6.10f,%6.10f\n' % (Data[0],Data[1]))
temp.close()
#----------------------------------------------------------------------------

xy3.setValues(sourceDescription='combine ( "XYData-1-e1","XYData-1-q" )')
tmpName = xy3.name
session.xyDataObjects.changeKey(tmpName, 'XYData-1-e1-q')
xy1 = session.xyDataObjects['XYData-1-e1']
xy2 = session.xyDataObjects['XYData-1-ev']
xy3 = combine(xy1, xy2)

#----------------------------------------------------------------------------
# �����
xy_result2 = session.XYData(name='XYData-1e1ev', objectToCopy=xy3, 
    sourceDescription='combine("XYData-1-e1", "XYData-1-ev" )')
######################################################################
temp=open('duncanAbaquse1ev.dat', 'w')
for  Data in xy_result2:
      print  Data
      temp.write('%6.10f,%6.10f\n' % (Data[0],Data[1]))
temp.close()

xy3.setValues(sourceDescription='combine ( "XYData-1-e1","XYData-1-ev" )')
tmpName = xy3.name
#----------------------------------------------------------------------------

session.xyDataObjects.changeKey(tmpName, 'XYData-1-e1-ev')
x0 = session.xyDataObjects['XYData-1-e1-ev']
x1 = session.xyDataObjects['XYData-1-e1-q']
session.xyReportOptions.setValues(layout=SEPARATE_TABLES)
session.writeXYReport(fileName='abaqus.rpt', appendMode=OFF, xyData=(x0, x1))

# ��������
#xy2 = (x0, x1)
#xy_result = session.XYData(name='XYData-1e1q1ev', objectToCopy=xy2, 
#    sourceDescription='combine("XYData-1-e1-ev", "XYData-1-e1-q" )')
######################################################################
# temp=open('csuhAbaquse1q1e1evt.dat', 'w')
#for  Data in xy_result:
#      print  Data
#       temp.write('%6.10f,%6.10f,%6.10f,%6.10f\n' % (Data[0,0],Data[0,1],Data[1,0],Data[1,1]))

# temp.close()


#mdb.save()
#: ģ�����ݿ��ѱ��浽 "E:\abaqus\UMAT\autoVertifyConstiviveModelUmat\CSUH\CSUH2.cae".
